import axios from "axios";
import {
  GET_ERRORS,
  GET_BACKLOG,
  DELETE_PROJECT_TASK,
  GET_PROJECT_TASK,
} from "./types";

export const addProjectTask = (uniquePid, project_task, history) => async (
  dispatch
) => {
  try {
    await axios.post(
      `http://localhost:7171/story/add/${uniquePid}`,
      project_task
    );
    history.push(`/projectBoard/${uniquePid}`);
    dispatch({
      type: GET_ERRORS,
      payload: {},
      uniquePid,
    });
  } catch (err) {
    dispatch({
      type: GET_ERRORS,
      payload: err.response.data,
    });
  }
};

export const getBacklog = (sid) => async (dispatch) => {
  try {
    const res = await axios.get(`http://localhost:7171/story/get/${sid}`);
    dispatch({
      type: GET_BACKLOG,
      payload: res.data,
    });
  } catch (err) {
    dispatch({
      type: GET_ERRORS,
      payload: err.response.data,
    });
  }
};

export const deleteProjectTask = (sid) => async (dispatch) => {
  if (
    window.confirm(
      `You are deleting project task ${sid}, this action cannot be undone`
    )
  )
    await axios.delete(`http://localhost:7171/story/delete/${sid}`);
  dispatch({
    type: DELETE_PROJECT_TASK,
    payload: sid,
  });
};

export const getProjectTask = (sid, history) => async (dispatch) => {
  try {
    const res = await axios.get(`http://localhost:7171/story/getStory/${sid}`);
    dispatch({
      type: GET_PROJECT_TASK,
      payload: res.data,
    });
  } catch (error) {
    // history.push("/");
  }
};
