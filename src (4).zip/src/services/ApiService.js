import axios from 'axios';
const Register_URL = 'http://localhost:7171/user/register';
const AddProject_URL = 'http://localhost:7171/project/create';

class ApiService {
  addUser(u) {
    console.log(u);
    return axios.post(Register_URL, u);
  }
  login(email, password) {
    console.log(email, password);
    return axios.get(
      `http://localhost:7171/api/auth/signin/${email}/${password}`
    );
  }
  addProject(projectDetails) {
    let axiosConfig = {
      headers: {
        "Content-Type": "application/json; charset=UTF-8",
        "Access-Control-Allow-Origin": "null",
      },
    };
    return axios.post(AddProject_URL, projectDetails, axiosConfig);
  }
}

export default new ApiService();