import axios from "axios";
import {
  GET_ERRORS,
  GET_PROJECT_TASKS,
  DELETE_PROJECT_TASK,
  GET_PROJECT_TASK,
} from "./types";

export const addProjectTask = (id, project_task, history) => async (
  dispatch
) => {
  try {
    await axios.post(`http://localhost:7171/story/add/${id}`, project_task);
    history.push("/projectBoard");
    dispatch({
      type: GET_ERRORS,
      payload: {},
    });
  } catch (error) {
    dispatch({
      type: GET_ERRORS,
      payload: error.response.data,
    });
  }
};
export const updateProjectTask = (sid, project_task, history) => async (
  dispatch
) => {
  try {
    await axios.put(`http://localhost:7171/story/update/${sid}`, project_task);
    history.push("/projectBoard");
    dispatch({
      type: GET_ERRORS,
      payload: {},
    });
  } catch (error) {
    dispatch({
      type: GET_ERRORS,
      payload: error.response.data,
    });
  }
};

export const getBacklog = id => async (dispatch) => {
  try {
    const res = await axios.get(`http://localhost:7171/story/get/$(id)`);
    dispatch({
      type: GET_PROJECT_TASKS,
      payload: res.data,
    });
  } catch (err) {
    dispatch({
      type: GET_ERRORS,
      payload: err.response.data,
    });
  }
};

export const deleteProjectTask = (sid) => async (dispatch) => {
  if (
    window.confirm(
      `You are deleting project task ${sid}, this action cannot be undone`
    )
  )
    await axios.delete(`http://localhost:7171/story/delete/${sid}`);
  dispatch({
    type: DELETE_PROJECT_TASK,
    payload: sid,
  });
};

export const getProjectTask = (id, history) => async (dispatch) => {
  try {
    const res = await axios.get(`http://localhost:7171/story/getStory/${id}`);
    dispatch({
      type: GET_PROJECT_TASK,
      payload: res.data,
    });
  } catch (error) {
    // history.push("/");
  }
};
