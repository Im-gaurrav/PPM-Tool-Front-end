import React, {Component} from "react";
import logo from './logo.svg';
import {BrowserRouter as Router,Route } from "react-router-dom"
import Login from "./Login.js";
import Register from "./Project/Register.js";
import {Nav,NavLink,NavItem} from "reactstrap";

class Header extends Component{
    render(){
        return (
        <Router>
        <Nav className="navbar navbar-expand-sm navbar-dark mb-4">
        {/* <Navbar> */}
        <NavItem className="NavbarBrand">
           <img src={logo} className="logo" alt="logo" />
            </NavItem>
        
        <NavLink className="navbar-brand" href="dashboard">
                <p>Personal Project Management Tool</p>
            </NavLink>
        <div className="container">
            <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#mobile-nav">
                <span className="navbar-toggler-icon" />
            </button>

            <div className="collapse navbar-collapse" id="mobile-nav">
                <div className="container">
                <NavItem>
                    <NavLink href="dashboard"><label>Dashboard</label></NavLink>
                </NavItem>

                <NavItem>
                    <NavLink href="register"><label>Sign up</label></NavLink>
                </NavItem>

                <NavItem>
                    <NavLink href="login"><label>Log in</label></NavLink>
                </NavItem>
                </div>
            </div>
        </div>
    {/* </Navbar> */}
    </Nav>
    <Route exact path="/login" component={Login}></Route>
    <Route exact path="/register" component={Register}></Route>
    </Router>
    
    
    )
        }
    }

export default Header;