import React, {Component} from "react";
class ProjectItems extends Component{
    render(){
        return <h1>Project Item</h1>
        }
    }

export default ProjectItems;