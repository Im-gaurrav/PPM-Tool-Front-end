import axios from 'axios';

// const USER_API_BASE_URL = 'http://localhost:7070/user';
const Register_URL = 'http://localhost:7070/user/register';

class ApiService {

    // fetchUsers() {
    //     return axios.get(USER_API_BASE_URL);
    // }

    // fetchUserById(userId) {
    //     return axios.get(USER_API_BASE_URL + '/' + userId);
    // }

    // deleteUser(userId) {
    //     return axios.delete(USER_API_BASE_URL + '/' + userId);
    // }

    addUser(u) {
        return axios.post(""+Register_URL, u);
    }

    // editUser(user) {
    //     return axios.put(USER_API_BASE_URL + '/' + user.id, user);
    // }

}

export default new ApiService();